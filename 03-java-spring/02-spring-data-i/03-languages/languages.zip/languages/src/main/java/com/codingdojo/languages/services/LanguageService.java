package com.codingdojo.languages.services;


import java.util.List;

import org.springframework.stereotype.Service;

import com.codingdojo.languages.models.Language;
import com.codingdojo.languages.repositories.LanguageRepository;


@Service
public class LanguageService {
	private LanguageRepository languageRepo;

	public LanguageService(LanguageRepository languageRepo) {
		
		this.languageRepo = languageRepo;
	}
	//Get all languages
	public List<Language> getAllLanguages(){
		return this.languageRepo.findAll();
	}
	//Create a language
	public Language create(Language language) {
		return this.languageRepo.save(language);
	}

}
